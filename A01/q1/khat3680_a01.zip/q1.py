'''
Created on Sep. 14, 2019

@author: AnshulKhatri
'''
print('The book title is, "Learn Python in 21 Days"')
print("What's mine is mine, and what's yours is mine")
print('"You have enemies? Good. That means youve stood up for something, sometime in your life." Winston Churchill')
print("Three things cannot be long hidden: the sun, the moon, and the truth.")